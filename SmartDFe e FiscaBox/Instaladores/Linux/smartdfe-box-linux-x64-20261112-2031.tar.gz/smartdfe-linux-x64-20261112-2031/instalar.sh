#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# instalar.sh — instala o pacote SmartDFe Linux x86-64 num PDV.
#
#   sudo ./instalar.sh
#
# Ele PERGUNTA o Client ID do Veraciti, que e o que permite ao aparelho se
# autorizar. Para instalar em escala, sem ninguem na frente do terminal:
#
#   sudo ./instalar.sh --client-id=SEU_CLIENT_ID
#   CLIENT_ID=SEU_CLIENT_ID sudo -E ./instalar.sh
#
# Num PDV JA provisionado o client_id existente e PRESERVADO — o script nunca
# sobrescreve a identidade de um aparelho que ja esta autorizado.
#
# IDEMPOTENTE: pode rodar de novo por cima de uma instalacao existente. Dado do
# cliente nunca e sobrescrito — bancos, hub_config.json, SmartNFCeConfig.json e
# certificados ja presentes ficam como estao.
#
# O QUE ESTE SCRIPT NAO FAZ, E POR QUE
#
# 1. Nao pede serie nem numero de nota, e nao semeia o contexto.db. A numeracao
#    e um contador que o motor administra; semear pela instalacao e caminho
#    direto para nota duplicada.
#
# 2. Nao leva certificado .pfx do cliente nem senha. "Situacao de fabrica" e sem
#    certificado: ele entra depois, pelo provisionamento do Veraciti.
#
# 3. Nao grava /etc/systemd/system/smartdfehub.service. Esse arquivo pertence ao
#    MOTOR: a lambda relancaHub (main.cpp:12692-12709) o reescreve com fopen
#    "wb" — que TRUNCA — no start e a cada 5 minutos, sempre que encontra o Hub
#    instalado e fora do ar. Qualquer unit que o instalador escrevesse ali seria
#    destruida em silencio, levando junto o User=, o Environment= e os limites.
#    Ajuste do Hub vai em /etc/systemd/system/smartdfehub.service.d/override.conf,
#    que o motor nao toca e que o daemon-reload dele carrega.
#
# 4. Nao instala o Hub direto em /data/smartdfe/hub. Quem instala e o motor: o
#    ensureHub() procura um SEED em /data/smartnfce/SmartDFeHub, compara o MD5 com
#    o /data/smartdfe/hub/.applied e, se for novo, para o servico, troca o
#    binario, PRESERVA o hub_config.json do cliente e da enable --now. Esse e o
#    caminho de atualizacao do produto. Competir com ele deixaria o .applied
#    inconsistente e o Hub seria reinstalado a cada 5 minutos.
#
# 5. Nao cria /data/pending como diretorio. Apesar do nome, e um ARQUIVO-bandeira
#    que o motor grava com fopen(...,"wt") (statusdevice.cpp:195) para sinalizar
#    contingencia. Criar como pasta faz o fopen falhar e a sinalizacao morrer
#    calada.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

AQUI="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ─── Schemas e certificados: origem ──────────────────────────────────────────
# Nao vem no pacote de binarios, e isso e deliberado: sao dado de ambiente, com
# ciclo de vida proprio — mudam por Nota Tecnica, nao por compilacao. Popular
# e trabalho DESTA etapa.
#
# Por padrao procuramos ao lado deste script, para quem monta um pacote completo
# soltando as duas pastas aqui. Quem guarda esses dados em outro lugar aponta:
#
#   sudo ./instalar.sh --schemas=/srv/fiscal/Schemas --certs=/srv/fiscal/certificados
DIR_SCHEMAS=""
DIR_CERTS=""
DIR_TLS=""
CLIENT_ID="${CLIENT_ID:-}"
SEM_CLIENT_ID="${SEM_CLIENT_ID:-0}"
while [ $# -gt 0 ]; do
  case "$1" in
    --schemas=*)   DIR_SCHEMAS="${1#*=}" ;;
    --certs=*)     DIR_CERTS="${1#*=}" ;;
    --tls=*)       DIR_TLS="${1#*=}" ;;
    --client-id=*) CLIENT_ID="${1#*=}" ;;
    --sem-client-id) SEM_CLIENT_ID=1 ;;
    -h|--help)
      echo "uso: sudo $0 [--client-id=ID] [--schemas=DIR] [--certs=DIR] [--tls=DIR]"
      echo
      echo "  --client-id=ID   Client ID do Veraciti deste PDV (24 caracteres)."
      echo "                   Sem ele, o script PERGUNTA. Em instalacao automatizada,"
      echo "                   passe aqui ou pela variavel CLIENT_ID."
      echo "  --sem-client-id  instala sem pedir; preenche depois pelo dashboard."
      echo "  --schemas=DIR    pasta com os XSD da SEFAZ"
      echo "  --certs=DIR      pasta com a cadeia ICP-Brasil e o cacert.pem"
      echo "  --tls=DIR        pasta com localhost.crt e localhost.key (par da porta 9014)"
      echo
      echo "sem os parametros, procura Schemas/ e certificados/ ao lado deste script,"
      echo "e o par localhost.crt/.key na raiz dele"
      echo
      echo "Num PDV JA provisionado o client_id existente e preservado: o script nunca"
      echo "sobrescreve a identidade de um aparelho que ja esta autorizado."
      exit 0 ;;
    *) echo "argumento desconhecido: $1 (use --help)"; exit 1 ;;
  esac
  shift
done
[ -n "$DIR_SCHEMAS" ] || DIR_SCHEMAS="$AQUI/Schemas"
[ -n "$DIR_CERTS" ]   || DIR_CERTS="$AQUI/certificados"
# O par TLS fica na RAIZ do pacote, nao numa subpasta, porque e assim que ele
# vive no destino: /data/smartnfce/localhost.crt, ao lado do emissor/ — espelho
# do layout do Windows, onde esta em C:\smartnfce\.
[ -n "$DIR_TLS" ]     || DIR_TLS="$AQUI"

# Acumula o que ficou faltando, para o resumo final poder ser categorico.
PENDENTE=""

RAIZ=/data/smartnfce
EMI=$RAIZ/emissor
HUB=/data/smartdfe/hub
SUP=/data/smartupdate          # smartdfe-updater: binario, lib, inbox e logs
UNITS=/etc/systemd/system

msg()  { echo; echo "=== $* ==="; }
ok()   { echo "  [ok] $*"; }
avisa(){ echo "  [aviso] $*"; }
morre(){ echo; echo "ABORTADO: $*"; exit 1; }

# ── 0. sanidade ─────────────────────────────────────────────────────────────
msg "[0/6] Conferindo o ambiente"

[ "$(id -u)" = "0" ] || morre "rode com sudo: o instalador escreve em /data e em $UNITS"
[ -d "$AQUI/emissor" ] || morre "nao achei a pasta emissor/ ao lado deste script. Descompacte o pacote e rode de dentro dele."

TEM_SYSTEMD=0
if command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ]; then
  TEM_SYSTEMD=1
  ok "systemd presente"
else
  avisa "systemd ausente ou inativo — os servicos nao serao registrados."
  avisa "O motor tem um caminho alternativo (nohup) para o Hub, mas o emissor e a"
  avisa "contingencia precisarao ser iniciados pelo mecanismo da sua distribuicao."
fi

# Qual binario este pacote traz? Cada rodada do construir.sh gera UM dos dois.
# Conferimos pelo DEFINE dentro do ELF, nao pelo nome do arquivo — ja houve caso
# de dois arquivos com nomes diferentes e conteudo identico, ambos contingencia.
marca_cont() { grep -a -q '__CONTIGENCIA__ ATIVO' "$1" 2>/dev/null; }

TEM_EMI=0; TEM_CONT=0
if [ -f "$AQUI/emissor/smartnfce" ]; then
  if marca_cont "$AQUI/emissor/smartnfce"; then
    morre "o arquivo emissor/smartnfce e um binario de CONTINGENCIA (contem o marcador
  __CONTIGENCIA__ ATIVO). Instalar assim poria dois agentes de contingencia no ar e
  nenhum emissor: a 3001 ficaria sem ninguem ouvindo e o PDV nao emitiria.
  Recompile com a linha 30 do examples/context.h COMENTADA."
  fi
  TEM_EMI=1; ok "pacote traz o EMISSOR (smartnfce)"
fi
if [ -f "$AQUI/emissor/contigencia" ]; then
  marca_cont "$AQUI/emissor/contigencia" || \
    morre "o arquivo emissor/contigencia NAO tem o marcador __CONTIGENCIA__ ATIVO —
  e um binario de emissor com nome de contingencia. Recompile com a linha 30 do
  examples/context.h ATIVA."
  TEM_CONT=1; ok "pacote traz a CONTINGENCIA (contigencia)"
fi
[ $TEM_EMI -eq 1 ] || [ $TEM_CONT -eq 1 ] || morre "o pacote nao traz nenhum binario do motor em emissor/"

[ -f "$AQUI/emissor/SmartDFeHub" ] && ok "pacote traz o Hub" || avisa "pacote SEM o Hub"

# ── 1. diretorios ───────────────────────────────────────────────────────────
msg "[1/6] Criando os diretorios"

# Ordem por gravidade. O primeiro e o unico que ABORTA o processo se faltar:
# controller e controllerCont (main.cpp:1646-1647) sao objetos GLOBAIS, abrem
# nfce.db e nfcecont.db ANTES do main(), e o throw de BD.h:2678 nao tem catch
# possivel num construtor estatico — o processo morre em
# "unable to open database file / terminate / Aborted". Nada no motor cria essa
# pasta no boot normal: o unico create_directories(BD) esta dentro do
# FactoryResetGuard, que retorna na hora se o factory_reset.flag nao existir.
for d in "$RAIZ/BD" \
         "$RAIZ/BD/fallback" \
         "$RAIZ" \
         "$EMI" \
         "$RAIZ/certificados" \
         "$RAIZ/certifcados" \
         "$RAIZ/Schemas" \
         "$HUB" \
         "$HUB/config" \
         "$HUB/lib" \
         "$HUB/plugins/sqldrivers"; do
  mkdir -p "$d"; chmod 0755 "$d"
done

# Arvore do smartdfe-updater. Criada AQUI, pela instalacao, e nao a mao em cada
# PDV: a inbox e o download ficam 0700 porque o pending_update.json carrega a
# download_url PRE-ASSINADA do pacote e nela mora o pacote baixado; a raiz e o
# logs/ ficam 0755, senao nem `ls /data/smartupdate` nem o status.json podem ser
# lidos sem sudo — e sao exatamente o que o suporte precisa ver.
for d in "$SUP" "$SUP/logs" "$SUP/backup"; do mkdir -p "$d"; chmod 0755 "$d"; done
for d in "$SUP/inbox" "$SUP/download";  do mkdir -p "$d"; chmod 0700 "$d"; done
mkdir -p "$SUP/lib"; chmod 0755 "$SUP/lib"
ok "$RAIZ/BD criado — e o que impede o motor de abortar antes do main()"
ok "Schemas com S maiusculo, como o codigo procura"

# A grafia dupla: nota.cpp:650 pede ICP-Brasil.crt em /certifcados/ (SEM o "i")
# enquanto as linhas 651-653 pedem v2/v5/v10 em /certificados/. No Windows tudo
# cai em C:/smartnfce/certificados/ e o defeito nunca apareceu. No Linux sao duas
# pastas diferentes, e a falha e MUDA porque config.cpp:61 descarta o retorno de
# insertCAcert(). Criamos as duas como contorno de uma linha.
ok "certificados/ e certifcados/ — as duas grafias, contorno do defeito de nota.cpp:650"

# ── 2. motor ────────────────────────────────────────────────────────────────
msg "[2/6] Instalando o motor em $EMI"

[ $TEM_EMI  -eq 1 ] && { install -m 0755 "$AQUI/emissor/smartnfce"  "$EMI/smartnfce";  ok "smartnfce"; }
[ $TEM_CONT -eq 1 ] && { install -m 0755 "$AQUI/emissor/contigencia" "$EMI/contigencia"; ok "contigencia"; }

mkdir -p "$EMI/lib" "$EMI/plugins/sqldrivers"
cp -a "$AQUI/emissor/lib/." "$EMI/lib/" 2>/dev/null || true
ok "lib/ com $(find "$EMI/lib" -maxdepth 1 -type f | wc -l) arquivos (achadas por rpath \$ORIGIN/lib)"

# ── smartdfe-updater ────────────────────────────────────────────────────────
# O binario e a lib/ dele vao JUNTOS: o rpath e $ORIGIN/lib, e sem as .so ao lado
# ele morre em "libcrypto.so.1.1: cannot open shared object file" — a distro do
# PDV costuma ter OpenSSL diferente da imagem onde o pacote foi compilado.
if [ -x "$AQUI/smartupdate/smartdfe-updater" ]; then
  install -m 0755 "$AQUI/smartupdate/smartdfe-updater" "$SUP/smartdfe-updater"
  cp -a "$AQUI/smartupdate/lib/." "$SUP/lib/" 2>/dev/null || true
  ok "smartdfe-updater + lib/ com $(find "$SUP/lib" -maxdepth 1 -type f 2>/dev/null | wc -l) arquivos"
else
  avisa "o pacote nao trouxe o smartdfe-updater — veja o AVISO do construir.sh"
fi

if [ -f "$AQUI/emissor/plugins/sqldrivers/libqsqlite.so" ]; then
  install -m 0644 "$AQUI/emissor/plugins/sqldrivers/libqsqlite.so" "$EMI/plugins/sqldrivers/"
fi
[ -f "$AQUI/emissor/qt.conf" ] && install -m 0644 "$AQUI/emissor/qt.conf" "$EMI/qt.conf"

# ── Client ID do Veraciti ───────────────────────────────────────────────────
# O motor le NFCe.client_id (deviceflow.cpp:575) para iniciar o Device Flow. Sem
# ele, o aparelho nao se autoriza e nao emite: o PDV instala, sobe e fica
# esperando uma autorizacao que nunca comeca.
#
# Regras:
#   - PDV ja provisionado (arquivo com client_id preenchido): NAO TOCA. Aquele
#     arquivo carrega a identidade do cliente.
#   - instalacao nova: pede o Client ID e grava.
#   - em escala, sem ninguem na frente do terminal: CLIENT_ID=xxx sudo ./instalar.sh
#     (ou --client-id=xxx). Com SEM_CLIENT_ID=1 instala sem pedir, para preencher
#     depois pelo dashboard.
msg "[2b/6] Client ID do Veraciti"

cfg="$EMI/SmartNFCeConfig.json"

# Le o client_id atual, se houver. Sem jq (nao esta garantido num PDV): grep no
# formato que o motor grava, com o valor entre aspas depois da chave.
client_id_atual() {
  [ -f "$cfg" ] || return 0
  sed -n 's/.*"client_id"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$cfg" | head -1
}

valida_client_id() {   # $1 = valor; devolve 0 se parece um client_id do Veraciti
  case "$1" in
    ''|*[!A-Za-z0-9_-]*) return 1 ;;
  esac
  [ "${#1}" -ge 16 ] && [ "${#1}" -le 64 ]
}

ATUAL="$(client_id_atual)"

if [ -n "$ATUAL" ]; then
  ok "client_id ja configurado (${ATUAL%"${ATUAL#????????}"}...) — PRESERVADO"
  ok "SmartNFCeConfig.json ja existe — PRESERVADO"
else
  NOVO="${CLIENT_ID:-}"

  if [ -z "$NOVO" ] && [ "${SEM_CLIENT_ID:-0}" != "1" ]; then
    if [ -t 0 ]; then
      echo
      echo "  O Client ID identifica este PDV no Veraciti. Ele esta no cadastro do"
      echo "  aparelho, no console (console.veraciti.com.br), e tem 24 caracteres."
      echo
      echo "  Para preencher depois, pelo dashboard, deixe em branco e pressione Enter."
      echo
      while :; do
        printf "  Client ID: "
        read -r NOVO || NOVO=""
        [ -z "$NOVO" ] && break
        valida_client_id "$NOVO" && break
        echo "  valor invalido: 16 a 64 caracteres, so letras, numeros, '-' e '_'."
      done
      echo
    else
      avisa "instalacao nao-interativa sem CLIENT_ID= — o PDV vai subir sem client_id"
    fi
  fi

  if [ -n "$NOVO" ] && ! valida_client_id "$NOVO"; then
    morre "CLIENT_ID invalido: '$NOVO'
       Esperado de 16 a 64 caracteres, so letras, numeros, '-' e '_'."
  fi

  # Grava preservando o resto do arquivo. O caso comum e instalacao nova, em que
  # o arquivo nem existe; o caminho do meio (arquivo com conteudo mas sem
  # client_id) usa python3 quando houver, porque mexer em JSON com sed e caminho
  # para corromper a config do cliente.
  if [ -z "$NOVO" ]; then
    [ -f "$cfg" ] || { echo '{}' > "$cfg"; chmod 0644 "$cfg"; }
    avisa "sem client_id: o aparelho NAO vai se autorizar ate ser preenchido."
    avisa "   Preencha em NFCe.client_id de $cfg, ou pelo dashboard, e reinicie:"
    avisa "   sudo systemctl restart smartnfce-emissor"
  elif [ ! -f "$cfg" ] || [ "$(tr -d ' \t\n\r' < "$cfg")" = "{}" ] || [ ! -s "$cfg" ]; then
    printf '{\n    "NFCe": {\n        "client_id": "%s"\n    }\n}\n' "$NOVO" > "$cfg"
    chmod 0644 "$cfg"
    ok "client_id gravado em NFCe.client_id"
  elif command -v python3 >/dev/null 2>&1; then
    python3 - "$cfg" "$NOVO" <<'PY'
import json, sys, io
caminho, valor = sys.argv[1], sys.argv[2]
with io.open(caminho, encoding='utf-8', errors='surrogateescape') as f:
    d = json.load(f)
d.setdefault('NFCe', {})['client_id'] = valor
tmp = caminho + '.tmp'
with io.open(tmp, 'w', encoding='utf-8', errors='surrogateescape') as f:
    json.dump(d, f, indent=4, ensure_ascii=False, sort_keys=True)
    f.write('\n')
import os
os.replace(tmp, caminho)
PY
    if [ $? -eq 0 ]; then
      chmod 0644 "$cfg"
      ok "client_id gravado em NFCe.client_id (resto da config preservado)"
    else
      morre "nao consegui gravar o client_id em $cfg — o arquivo nao foi alterado.
       Preencha NFCe.client_id a mao e rode: sudo systemctl restart smartnfce-emissor"
    fi
  else
    avisa "o $cfg tem conteudo e nao ha python3 nesta maquina para edita-lo com"
    avisa "   seguranca. NAO vou mexer nele: config de cliente corrompida e pior que"
    avisa "   client_id faltando. Preencha NFCe.client_id = \"$NOVO\" a mao e rode:"
    avisa "   sudo systemctl restart smartnfce-emissor"
  fi
fi

# ─── Base de Referencia Fiscal ───────────────────────────────────────────────
# A bootstrapConfigFiscalMotor() do motor le estes dois caminhos e os copia para
# /data/smartnfce/config, que e o diretorio do preValidador(). Se a semente
# faltar, ela retorna CALADA e a pre-validacao nao existe naquele PDV — nada
# falha e nada aparece no log. Por isso entra na lista de pendencias no fim.
if [ -f "$AQUI/emissor/regras_fiscais.json" ]; then
  install -m 0644 "$AQUI/emissor/regras_fiscais.json" "$EMI/regras_fiscais.json"
  ok "regras_fiscais.json"
  if [ -d "$AQUI/emissor/fiscal" ]; then
    mkdir -p "$EMI/fiscal"; chmod 0755 "$EMI/fiscal"
    cp -a "$AQUI/emissor/fiscal/." "$EMI/fiscal/"
    ok "fiscal/ ($(find "$EMI/fiscal" -name '*.json' | wc -l) tabelas)"
  else
    avisa "o pacote trouxe o catalogo mas nao a pasta fiscal/"
    PENDENTE="$PENDENTE tabelas-fiscais"
  fi
else
  avisa "o pacote nao trouxe regras_fiscais.json"
  PENDENTE="$PENDENTE base-fiscal"
fi

# ── 3. dados ────────────────────────────────────────────────────────────────
msg "[3/6] Populando Schemas e cadeia de certificados"

# Schemas XSD da SEFAZ. Sem eles a validacao do XML falha NA EMISSAO, nao no
# boot — foi assim que o erro de schema IBS/CBS apareceu no M11, e naquele caso
# a pasta existia, so estava velha. Por isso contamos os XSD em vez de so
# conferir se o diretorio existe: pasta vazia e tao ruim quanto pasta ausente, e
# muito mais enganosa.
if [ -d "$DIR_SCHEMAS" ] && [ -n "$(find "$DIR_SCHEMAS" -name '*.xsd' -print -quit 2>/dev/null)" ]; then
  cp -a "$DIR_SCHEMAS/." "$RAIZ/Schemas/"
  ok "Schemas <- $DIR_SCHEMAS ($(find "$RAIZ/Schemas" -name '*.xsd' | wc -l) XSD)"
else
  avisa "nenhum XSD em $DIR_SCHEMAS"
  PENDENTE="$PENDENTE Schemas"
fi

# Cadeia ICP-Brasil e cacert.pem. NAO vai certificado do cliente (.pfx) nem
# senha: situacao de fabrica e sem certificado, e ele entra no provisionamento.
if [ -d "$DIR_CERTS" ] && [ -n "$(find "$DIR_CERTS" -type f -print -quit 2>/dev/null)" ]; then
  cp -a "$DIR_CERTS/." "$RAIZ/certificados/"
  # O ICP-Brasil.crt tambem na grafia SEM o "i", que e de onde nota.cpp:650 o le.
  #
  # ⚠️ O arquivo "ICP-Brasil.crt" sem numero de versao NAO EXISTE em distribuicao
  # nenhuma: o que se distribui e ICP-Brasilv5.crt, v10, v11. Conferido em
  # C:\templateNFCe\smartnfce\certificados e em C:\smartnfce\certificados — nos
  # dois ha so as versionadas. No Windows isso nunca apareceu porque a falha de
  # leitura e MUDA (config.cpp:61 descarta o retorno) e tudo cai na mesma pasta.
  #
  # Antes este script apenas AVISAVA e marcava pendente, o que fazia a instalacao
  # terminar com "INSTALACAO INCOMPLETA" e exit 3 em TODO PDV — alarme falso que
  # em campo manda procurar um arquivo que nao existe. Agora resolvemos: a cadeia
  # de maior versao e espelhada COMO ICP-Brasil.crt, que e o nome que o motor pede.
  if [ -f "$RAIZ/certificados/ICP-Brasil.crt" ]; then
    install -m 0644 "$RAIZ/certificados/ICP-Brasil.crt" "$RAIZ/certifcados/ICP-Brasil.crt"
    ok "cadeia <- $DIR_CERTS (ICP-Brasil.crt espelhado em certifcados/)"
  else
    # sort -V ordena por versao: v5 < v10 < v11 (o sort comum poria v10 antes de v5).
    ICP_NOVO="$(find "$RAIZ/certificados" -maxdepth 1 -name 'ICP-Brasil*.crt' -printf '%f\n' 2>/dev/null \
                | sort -V | tail -1)"
    if [ -n "$ICP_NOVO" ]; then
      install -m 0644 "$RAIZ/certificados/$ICP_NOVO" "$RAIZ/certifcados/ICP-Brasil.crt"
      install -m 0644 "$RAIZ/certificados/$ICP_NOVO" "$RAIZ/certificados/ICP-Brasil.crt"
      ok "cadeia <- $DIR_CERTS ($ICP_NOVO espelhado como ICP-Brasil.crt nas duas grafias)"
    else
      ok "cadeia <- $DIR_CERTS (sem ICP-Brasil*.crt; nao e usado na NFC-e)"
    fi
  fi
else
  # NAO e pendencia, e isto foi conferido no fonte em 09/11/2026:
  #
  #   httpqt.cpp:460-467  o curl da NFC-e no Linux roda com --insecure E --cacert
  #                       juntos. Com --insecure o CA bundle nao e carregado, logo
  #                       um cacert.pem ausente nao da erro e nao muda nada.
  #   dfemdfe.cpp:967-970 unico leitor de ICP-Brasil*.crt, e e codigo morto.
  #
  # Antes isto marcava PENDENTE e fazia o script terminar com "INSTALACAO
  # INCOMPLETA - o PDV NAO VAI EMITIR" e exit 3 em TODO PDV cujo pacote nao
  # trouxesse a pasta — que eram todos, porque o gerar-pacote.sh nao a copiava.
  # Alarme falso que manda procurar arquivo que nao entra na emissao.
  #
  # O que vive aqui em producao e o certificado.pfx do cliente (httpqt.cpp:588),
  # e esse vem do PROVISIONAMENTO, nunca de um pacote de instalacao.
  echo "  cadeia ICP-Brasil nao veio no pacote — opcional, nao entra na NFC-e."
fi

echo "  nenhum .pfx e nenhuma senha foram instalados — situacao de fabrica."

# ─── Par TLS do servidor seguro do motor (porta 9014) ────────────────────────
# securityServer.cpp:67 e :78 leem /data/smartnfce/localhost.crt e .key em
# caminho ABSOLUTO (no Windows, c://smartnfce/). Sem o par, o construtor do
# SecureTcpServer RETORNA antes de chamar listen() e a 9014 simplesmente nao
# sobe: nao ha erro no boot nem linha no journal. Quem fala TLS com o motor ve
# "conexao recusada" e vai procurar rede, longe da causa.
#
# E um par FIXO de distribuicao — o mesmo que o instalador do Windows ja leva no
# payload. Nao e gerado por maquina e nao e certificado do cliente, por isso
# pode viajar no pacote enquanto o .pfx nao pode.
if [ -f "$DIR_TLS/localhost.crt" ] && [ -f "$DIR_TLS/localhost.key" ]; then
  install -m 0644 "$DIR_TLS/localhost.crt" "$RAIZ/localhost.crt"
  install -m 0600 "$DIR_TLS/localhost.key" "$RAIZ/localhost.key"
  ok "par TLS da 9014 <- $DIR_TLS (a chave fica 0600)"
else
  avisa "nao achei localhost.crt e localhost.key em $DIR_TLS"
  PENDENTE="$PENDENTE tls-9014"
fi

# ── 4. Hub como SEED ────────────────────────────────────────────────────────
msg "[4/6] Preparando o Hub"

if [ -f "$AQUI/emissor/SmartDFeHub" ]; then
  # As BIBLIOTECAS do Hub o instalador coloca, porque o ensureHub() copia apenas
  # o binario — e o binario e linkado com rpath $ORIGIN/lib, logo procura em
  # /data/smartdfe/hub/lib, que o seed nunca povoa.
  cp -a "$AQUI/emissor/lib/." "$HUB/lib/" 2>/dev/null || true
  [ -f "$AQUI/emissor/plugins/sqldrivers/libqsqlite.so" ] && \
    install -m 0644 "$AQUI/emissor/plugins/sqldrivers/libqsqlite.so" "$HUB/plugins/sqldrivers/"
  [ -f "$AQUI/emissor/qt.conf" ] && install -m 0644 "$AQUI/emissor/qt.conf" "$HUB/qt.conf"
  ok "lib/, plugins/sqldrivers/ e qt.conf em $HUB"

  # O SEED. O motor o encontra em /data/smartnfce/SmartDFeHub (main.cpp:12665-12667),
  # compara o MD5 com o $HUB/.applied e instala sozinho.
  install -m 0755 "$AQUI/emissor/SmartDFeHub" "$RAIZ/SmartDFeHub"
  ok "seed em $RAIZ/SmartDFeHub — o motor instala no primeiro tique"

  # Semente de config: so e copiada pelo ensureHub se o hub_config.json ainda nao
  # existir, entao a config do cliente nunca e perdida numa reinstalacao.
  mkdir -p "$RAIZ/config"
  for c in hub_config.factory.json tributacao_kb.json; do
    [ -f "$AQUI/hub-config/$c" ] && install -m 0644 "$AQUI/hub-config/$c" "$RAIZ/config/$c" && ok "semente $c"
  done

  if [ $TEM_SYSTEMD -eq 1 ]; then
    # Drop-in: o unico lugar seguro para ajustar o Hub. O arquivo principal e
    # reescrito pelo motor; este diretorio ele nao toca.
    mkdir -p "$UNITS/smartdfehub.service.d"
    cat > "$UNITS/smartdfehub.service.d/override.conf" <<'FIM'
# Ajustes do SmartDFe Hub.
#
# NAO edite /etc/systemd/system/smartdfehub.service: o motor o reescreve do zero
# (fopen "wb" trunca) no start e a cada 5 minutos, sempre que acha o Hub
# instalado e fora do ar — ver relancaHub em main.cpp:12692-12709. Este drop-in
# sobrevive, porque o motor nunca mexe no diretorio .d.
[Unit]
# A unit que o motor grava nao tem isto. Sem o zero, o systemd desiste de
# reiniciar o Hub depois de 5 partidas em 10 s e o deixa fora do ar.
StartLimitIntervalSec=0

[Service]
# Unit de systemd roda sem HOME. Seguro barato: alguma rota do Bridge pode
# resolver caminho relativo a partir dele.
Environment=HOME=/data/smartdfe/hub
LimitNOFILE=8192
FIM
    ok "drop-in em $UNITS/smartdfehub.service.d/override.conf"
  fi
else
  avisa "sem o Hub no pacote, nada a semear."
fi

# ── 5. servicos ─────────────────────────────────────────────────────────────
msg "[5/6] Registrando os servicos"

if [ $TEM_SYSTEMD -eq 1 ]; then
  for u in smartnfce-emissor smartnfce-contingencia; do
    [ -f "$AQUI/systemd/$u.service" ] || { avisa "$u.service nao veio no pacote"; continue; }
    install -m 0644 "$AQUI/systemd/$u.service" "$UNITS/$u.service"
  done
  systemctl daemon-reload

  # Habilita SO a unit cujo binario este pacote entregou. Habilitar a outra
  # deixaria uma unit em estado de falha permanente, poluindo o status e
  # escondendo problema de verdade.
  #
  # ⚠️ enable + restart, NAO "enable --now".
  #
  # "enable --now" e enable + START, e start em unit JA ATIVA nao faz nada. Numa
  # REINSTALACAO — que e o caso normal, toda vez que se atualiza um PDV — os
  # binarios novos ja foram gravados com install() mais acima e o PROCESSO VELHO
  # continuava no ar rodando o binario antigo da memoria. Sem erro, sem log, sem
  # sintoma: o `systemctl status` dizia "active (running)", o `ls -l` mostrava o
  # binario novo, e o PDV seguia com o comportamento antigo. Era preciso lembrar
  # de um systemctl restart a mao depois de cada instalacao.
  #
  # "enable" garante o boot; "restart" sobe se estiver parada e RESUBE se estiver
  # ativa — nos dois casos o processo passa a ser o do binario novo.
  #
  # O restart do emissor tem um segundo efeito, igualmente necessario: e no start
  # que o motor roda o ensureHub, que compara o MD5 do seed com o .applied e troca
  # o binario do Hub. Sem reiniciar o motor, o Hub novo entraria so no tique
  # seguinte, ate 5 minutos depois — ou nunca, se o motor velho no ar for anterior
  # ao ensureHub.
  sobe_unit() {
    local u="$1" rotulo="$2"
    local estava="parada"
    # if, nao "cmd && var=x": com o set -e da linha 49, a lista && devolve 1
    # quando a unit esta parada (o caso NORMAL de instalacao nova) e o script
    # morreria aqui, sem mensagem.
    if systemctl is-active --quiet "$u"; then estava="ATIVA"; fi
    systemctl enable "$u" >/dev/null 2>&1 || avisa "nao consegui habilitar $u no boot"
    if systemctl restart "$u"; then
      if [ "$estava" = "ATIVA" ]; then
        ok "$rotulo: REINICIADO (estava no ar com o binario antigo) e habilitado no boot"
      else
        ok "$rotulo: iniciado e habilitado no boot"
      fi
    else
      avisa "$rotulo NAO subiu. Veja:  journalctl -u $u -n 30 --no-pager"
      PENDENTE="$PENDENTE $rotulo-nao-subiu"
    fi
  }

  if [ $TEM_EMI -eq 1 ] && [ -f "$UNITS/smartnfce-emissor.service" ]; then
    sobe_unit smartnfce-emissor.service smartnfce-emissor
  fi
  if [ $TEM_CONT -eq 1 ] && [ -f "$UNITS/smartnfce-contingencia.service" ]; then
    sobe_unit smartnfce-contingencia.service smartnfce-contingencia
  fi

  # smartdfe-updater: habilitado SEMPRE que o pacote o trouxe, independente da
  # variante. Ele nao e emissor nem contingencia — e quem aplica a PROXIMA
  # atualizacao. Sem ele de pe, o motor grava o pedido em $SUP/inbox e nada
  # acontece: nenhum erro, nenhum log, nenhum sintoma.
  if [ -x "$SUP/smartdfe-updater" ] && [ -f "$AQUI/systemd/smartdfe-updater.service" ]; then
    install -m 0644 "$AQUI/systemd/smartdfe-updater.service" "$UNITS/smartdfe-updater.service"
    systemctl daemon-reload
    # Mesmo motivo do sobe_unit acima: o daemon tambem e substituido em disco por
    # este instalador, e um "enable --now" deixaria o processo velho no ar.
    sobe_unit smartdfe-updater.service smartdfe-updater
    sleep 1
    systemctl is-active --quiet smartdfe-updater.service || \
      avisa "smartdfe-updater instalado mas NAO esta ativo. Veja:
         journalctl -u smartdfe-updater -n 20 --no-pager"
  else
    avisa "smartdfe-updater nao veio no pacote — este PDV nao vai APLICAR
         atualizacao nenhuma, mesmo recebendo o comando do Veraciti"
  fi

  # O smartdfehub NAO e habilitado aqui: quem faz isso e o motor, ao aplicar o
  # seed (systemctl enable --now dentro do relancaHub).
  echo "  o servico do Hub e registrado pelo proprio motor ao aplicar o seed."
else
  avisa "sem systemd: registre $EMI/smartnfce e $EMI/contigencia no mecanismo da distro."
fi

# ── 6. resumo ───────────────────────────────────────────────────────────────
msg "[6/6] Instalado"

cat <<FIM

  MOTOR     $EMI
  DADOS     $RAIZ/{BD,Schemas,certificados,certifcados}
  HUB       $HUB  (seed em $RAIZ/SmartDFeHub)

  Acompanhar:
    journalctl -u smartnfce-emissor -f
    journalctl -u smartdfehub -f
    systemctl status smartnfce-emissor smartnfce-contingencia smartdfehub

  O PDV fala HTTP puro com o motor na porta 3001.

FIM

if [ $TEM_EMI -eq 1 ] && [ $TEM_CONT -eq 0 ]; then
  avisa "este pacote trouxe SO o emissor. Sem o binario 'contigencia' o PDV nao"
  avisa "emite quando a SEFAZ estiver fora. Gere o par alternando a linha 30 do"
  avisa "examples/context.h e rode o instalador de novo."
elif [ $TEM_CONT -eq 1 ] && [ $TEM_EMI -eq 0 ]; then
  avisa "este pacote trouxe SO a contingencia. Sem o emissor nao ha ninguem"
  avisa "ouvindo na 3001 e o PDV nao emite."
fi

if [ -f "$AQUI/emissor/SmartDFeHub" ] && [ ! -f "$HUB/hub_config.json" ]; then
  echo
  echo "  DECISAO PENDENTE — licenciamento do Hub no Linux"
  echo
  echo "  Sem license.key preenchida no hub_config.json, o Hub sobe em MODO"
  echo "  RESTRITO: só as portas 8770 e 8781 ficam no ar. ACBr, Focus, InvoiCy e"
  echo "  a API nativa nao sobem."
  echo
  echo "  No Linux o LicenseGate e um stub permissivo, mas ele so e CONSULTADO"
  echo "  quando a chave e nao-vazia. Ou seja: qualquer valor nao-vazio libera"
  echo "  todos os adapters. Deixamos a chave VAZIA de proposito — preenche-la"
  echo "  aqui seria decidir, pela instalacao, que o Linux nao exige licenca."
  echo "  Essa decisao e de produto, nao do instalador."
  echo
fi

# ⚠️ Sai com codigo 3 quando ficou pendencia. O motor e o Hub ja estao no ar e a
# instalacao do software terminou — mas um PDV sem Schemas sobe, aceita a venda e
# falha NA EMISSAO. Terminar com 0 aqui significaria dizer "instalado" para algo
# que nao emite, e a moldura abaixo rolaria na tela de quem ja virou as costas.
if [ -n "$PENDENTE" ]; then
  echo "  ┌──────────────────────────────────────────────────────────────────┐"
  echo "  │ INSTALACAO INCOMPLETA — o PDV NAO VAI EMITIR                     │"
  echo "  └──────────────────────────────────────────────────────────────────┘"
  echo
  for p in $PENDENTE; do
    case "$p" in
      Schemas)
        echo "   - Schemas XSD da SEFAZ ausentes em $RAIZ/Schemas"
        echo "     A validacao do XML falha na emissao, nao no boot." ;;
      base-fiscal)
        echo "   - regras_fiscais.json ausente em $EMI"
        echo "     A pre-validacao fica DESLIGADA: a bootstrapConfigFiscalMotor()"
        echo "     retorna calada quando a semente falta, e nada aparece no log." ;;
      tabelas-fiscais)
        echo "   - pasta fiscal/ ausente em $EMI (o catalogo veio sozinho)"
        echo "     Sem as tabelas, a pre-validacao sobe com base incompleta." ;;
      tls-9014)
        echo "   - localhost.crt / localhost.key ausentes em $RAIZ"
        echo "     O SecureTcpServer retorna sem chamar listen() e a porta 9014"
        echo "     nao sobe — sem erro no boot (securityServer.cpp:67 e :78)." ;;
      *-nao-subiu)
        echo "   - o servico ${p%-nao-subiu} NAO subiu."
        echo "     Os arquivos foram instalados, mas o processo nao esta no ar:"
        echo "       journalctl -u ${p%-nao-subiu} -n 40 --no-pager" ;;
      *)
        echo "   - $p" ;;
    esac
  done
  echo
  echo "  Complete rodando de novo, apontando a origem:"
  echo "    sudo $0 --schemas=/caminho/Schemas --certs=/caminho/certificados"
  echo
  echo "  O script e idempotente: nada do que ja foi instalado se perde, e o"
  echo "  banco, o hub_config.json e o SmartNFCeConfig.json sao preservados."
  echo
  exit 3
fi
