package com.example.testenfce;

import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Rect;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.android.material.button.MaterialButton;

import br.com.ndd.fiscalagent.FiscalAgentController;
import com.elgin.smartdfe.DFeFuture;
import com.elgin.smartdfe.ItemVenda;
import com.elgin.smartdfe.PagamentoVenda;
import com.elgin.smartdfe.SmartDFe;
import com.elgin.smartdfe.SmartDFeHub;
import com.elgin.smartdfe.SmartDFeSdk;
import com.elgin.smartdfe.SmartDFeConfig;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Supplier;

import kotlin.Unit;

/** Tela de demonstração interativa da API documentada da SmartDFe. */
public class ApiMethodsActivity extends AppCompatActivity {

    private static final String PREFS_NOTAS = "smartdfe_demo";
    private static final String PREF_ULTIMA_CHAVE = "ultima_chave_acesso";
    private static final String PREF_MODO_ESCURO = "modo_escuro";

    private LinearLayout content;
    private LinearLayout sectionContent;
    private ScrollView pageScroll;
    private LinearLayout actionRow;
    private int actionsInRow;
    private boolean twoColumns;
    private TextView itemMenuSelecionado;
    private TextView status;
    private SmartDFeSdk sdk;
    private String ultimaChaveAcesso = "";
    private final FiscalAgentController fiscalAgent = new FiscalAgentController();
    private final ExecutorService initExecutor = Executors.newSingleThreadExecutor();
    private volatile AlertDialog activeResponseDialog;
    private volatile long dialogSequence;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        boolean modoEscuro = getSharedPreferences(PREFS_NOTAS, MODE_PRIVATE).getBoolean(PREF_MODO_ESCURO, false);
        AppCompatDelegate.setDefaultNightMode(modoEscuro
                ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
        sdk = SmartDFe.getSdk();
        ultimaChaveAcesso = getSharedPreferences(PREFS_NOTAS, MODE_PRIVATE)
                .getString(PREF_ULTIMA_CHAVE, "");

        twoColumns = getResources().getConfiguration().screenWidthDp >= 900;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(getColor(R.color.surface_app));
        if (twoColumns) {
            root.addView(criarBarraLateral(), new LinearLayout.LayoutParams(dp(252), ViewGroup.LayoutParams.MATCH_PARENT));
            View line = new View(this);
            line.setBackgroundColor(getColor(R.color.line_soft));
            root.addView(line, new LinearLayout.LayoutParams(dp(1), ViewGroup.LayoutParams.MATCH_PARENT));
        }

        ScrollView scroll = new ScrollView(this);
        pageScroll = scroll;
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = twoColumns ? dp(40) : dp(20);
        content.setPadding(pad, dp(28), pad, dp(36));
        content.setBackgroundColor(getColor(R.color.surface_app));
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        ScrollView.LayoutParams contentParams = new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        contentParams.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        scroll.addView(content, contentParams);
        root.addView(scroll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, windowInsets) -> {
            Insets bars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return windowInsets;
        });
        setContentView(root);

        criarCabecalho();
        // O indicador de status é criado no cabeçalho.
        status.setText("Toque em um método para executá-lo. Operações fiscais pedem confirmação.");
        status.setTextSize(14);
        status.setTextColor(getColor(R.color.ink_body));
        status.setPadding(0, 0, 0, dp(8));
        addNote("Diagnóstico: deixe instalado apenas um app que embarque o SmartDFe (portas 3001 e 8780 são compartilhadas pelo aparelho). No tablet Android 15, confira também o logcat com a etiqueta SmartDFe.");

        if (sdk == null) {
            addNote("Inicializando SmartDFe e ativando os serviços…");
            inicializarSdk();
            return;
        }

        montarBotoesApi();
    }

    private LinearLayout criarBarraLateral() {
        LinearLayout menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setPadding(dp(22), dp(34), dp(16), dp(24));
        menu.setBackgroundColor(getColor(R.color.white));

        TextView marca = new TextView(this);
        marca.setText("◆  SmartDFe");
        marca.setTextColor(getColor(R.color.ink_navy));
        marca.setTextSize(25);
        marca.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        menu.addView(marca, fullWidth());

        adicionarItemMenu(menu, "▱", "Provisionamento", true);
        adicionarItemMenu(menu, "ϟ", "Serviço", false);
        adicionarItemMenu(menu, "◇", "Hub", false);
        adicionarItemMenu(menu, "⌫", "Limpeza", false);
        adicionarItemMenu(menu, "▣", "NFC-e", false);
        adicionarItemMenu(menu, "▤", "NF-e", false);
        adicionarItemMenu(menu, "⌁", "Agente fiscal", false);
        adicionarItemMenu(menu, "ƒ", "DFeFuture", false);
        adicionarItemMenu(menu, "☷", "Configuração", false);

        View espaco = new View(this);
        menu.addView(espaco, new LinearLayout.LayoutParams(1, 0, 1));
        TextView rodape = new TextView(this);
        boolean modoEscuro = getSharedPreferences(PREFS_NOTAS, MODE_PRIVATE).getBoolean(PREF_MODO_ESCURO, false);
        rodape.setText(modoEscuro ? "☀  Modo claro" : "◐  Modo escuro");
        rodape.setTextColor(getColor(R.color.ink_body));
        rodape.setTextSize(15);
        rodape.setPadding(dp(10), dp(14), 0, dp(14));
        rodape.setMinHeight(dp(52));
        rodape.setGravity(android.view.Gravity.CENTER_VERTICAL);
        rodape.setClickable(true);
        rodape.setFocusable(true);
        rodape.setOnClickListener(v -> {
            getSharedPreferences(PREFS_NOTAS, MODE_PRIVATE).edit()
                    .putBoolean(PREF_MODO_ESCURO, !modoEscuro).apply();
            AppCompatDelegate.setDefaultNightMode(modoEscuro
                    ? AppCompatDelegate.MODE_NIGHT_NO : AppCompatDelegate.MODE_NIGHT_YES);
        });
        menu.addView(rodape, fullWidth());
        return menu;
    }

    private void adicionarItemMenu(LinearLayout menu, String icone, String texto, boolean selecionado) {
        TextView item = new TextView(this);
        item.setText(icone + "   " + texto);
        item.setTextSize(15);
        item.setGravity(android.view.Gravity.CENTER_VERTICAL);
        item.setPadding(dp(14), 0, dp(8), 0);
        estilizarItemMenu(item, selecionado);
        if (selecionado) itemMenuSelecionado = item;
        LinearLayout.LayoutParams params = fullWidth();
        params.height = dp(54);
        params.setMargins(0, dp(8), 0, 0);
        menu.addView(item, params);
        item.setClickable(true);
        item.setFocusable(true);
        item.setOnClickListener(v -> {
            if (itemMenuSelecionado != item) {
                if (itemMenuSelecionado != null) estilizarItemMenu(itemMenuSelecionado, false);
                estilizarItemMenu(item, true);
                itemMenuSelecionado = item;
            }
            navegarParaSecao(texto);
        });
    }

    private void estilizarItemMenu(TextView item, boolean selecionado) {
        item.setTextColor(getColor(selecionado ? R.color.ink_navy : R.color.ink_body));
        item.setTypeface(android.graphics.Typeface.DEFAULT,
                selecionado ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        GradientDrawable fundo = new GradientDrawable();
        fundo.setCornerRadius(dp(14));
        fundo.setColor(getColor(selecionado ? R.color.surface_status : R.color.white));
        item.setBackground(fundo);
    }

    private void navegarParaSecao(String grupo) {
        if (pageScroll == null) return;
        for (int i = 0; i < content.getChildCount(); i++) {
            View child = content.getChildAt(i);
            if (grupo.equals(child.getTag())) {
                Rect bounds = new Rect();
                content.offsetDescendantRectToMyCoords(child, bounds);
                pageScroll.smoothScrollTo(0, bounds.top);
                return;
            }
        }
    }

    private void criarCabecalho() {
        LinearLayout topo = new LinearLayout(this);
        topo.setOrientation(LinearLayout.HORIZONTAL);
        topo.setGravity(android.view.Gravity.CENTER_VERTICAL);

        LinearLayout texto = new LinearLayout(this);
        texto.setOrientation(LinearLayout.VERTICAL);
        TextView titulo = new TextView(this);
        titulo.setText("SmartDFe — Teste de Métodos");
        titulo.setTextColor(getColor(R.color.ink_navy));
        titulo.setTextSize(twoColumns ? 36 : 29);
        titulo.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        texto.addView(titulo, fullWidth());
        TextView subtitulo = new TextView(this);
        subtitulo.setText("Execute e valide os métodos da API SmartDFe.");
        subtitulo.setTextColor(getColor(R.color.ink_body));
        subtitulo.setTextSize(17);
        subtitulo.setPadding(0, dp(4), 0, 0);
        texto.addView(subtitulo, fullWidth());
        topo.addView(texto, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        if (twoColumns) {
            TextView ativo = new TextView(this);
            ativo.setText("●  SmartDFe ativo");
            ativo.setTextColor(getColor(R.color.ink_navy));
            ativo.setTextSize(16);
            ativo.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
            ativo.setGravity(android.view.Gravity.CENTER);
            GradientDrawable badge = new GradientDrawable();
            badge.setColor(getColor(R.color.surface_status));
            badge.setCornerRadius(dp(18));
            badge.setStroke(dp(1), getColor(R.color.line_soft));
            ativo.setBackground(badge);
            topo.addView(ativo, new LinearLayout.LayoutParams(dp(208), dp(54)));
        }
        content.addView(topo, fullWidth());

        status = new TextView(this);
        status.setText("Preparando SmartDFe…");
        status.setTextColor(getColor(R.color.ink_muted));
        status.setTextSize(14);
        status.setPadding(0, dp(18), 0, dp(2));
        content.addView(status, fullWidth());
        sectionContent = content;
    }

    private void montarBotoesApi() {
        addTitle("Provisionamento");
        addAction("estadoProvisionamento(context)", this::mostrarProvisionamento);
        addTitle("Serviço");
        addAction("isReady (aguardar até ficar true)", () -> confirmarEnvio("SmartDFe.isReady",
                "parâmetros = nenhum\nconsulta síncrona em segundo plano; repetida até true ou tempo limite",
                this::aguardarMotorPronto));
        addAction("Aguardar autorização (até 10 min)", () -> confirmarEnvio("estadoProvisionamento",
                "context = ApiMethodsActivity.this\nconsulta local a cada 5 segundos durante até 10 minutos",
                this::aguardarAutorizacao));
        addAction("ativarServico(context) — aguardar true", () -> confirmarEnvio("SmartDFe.ativarServico",
                "context = ApiMethodsActivity.this\nrepetir se retornar false = sim\nintervalo entre tentativas = 5 segundos\ntempo limite = 10 minutos",
                this::ativarESperar));
        addAction("desativarServico(context)", () -> confirmarEnvio("desativarServico",
                "context = ApiMethodsActivity.this\nforce = false\n\nO motor e o Hub serão desligados.",
                () -> run("desativarServico", SmartDFe.desativarServico(this))));
        addAction("desativarServico(context, true)", () -> confirmarEnvio("desativarServico",
                "context = ApiMethodsActivity.this\nforce = true\n\nPode perder notas de contingência ainda não transmitidas.",
                () -> run("desativarServico(force)", SmartDFe.desativarServico(this, true))));
        addAction("shutdown(context)", () -> confirmarEnvio("shutdown",
                "context = ApiMethodsActivity.this\n\nPara os serviços nesta sessão sem gravar o desligamento.",
                () -> { SmartDFe.shutdown(this); mostrar("shutdown", "chamada concluída"); }));
        addTitle("Limpeza");
        addAction("zerarProvisionamento(context)", () -> confirmarEnvio("zerarProvisionamento",
                "context = ApiMethodsActivity.this\nforce = false\n\nApaga estado local, banco, certificado e autorização.",
                () -> run("zerarProvisionamento", SmartDFe.zerarProvisionamento(this))));
        addAction("zerarProvisionamento(context, true)", () -> confirmarEnvio("zerarProvisionamento",
                "context = ApiMethodsActivity.this\nforce = true\n\nForça a limpeza mesmo com pendências fiscais e pode perder documentos.",
                () -> run("zerarProvisionamento(force)", SmartDFe.zerarProvisionamento(this, true))));
        addTitle("Configuração");
        addAction("Opções do SmartDFeConfig.Builder", () -> mostrar("Builder",
                "notificacao(titulo, texto)\nnotificacaoIcone(resId)\nreadinessTimeout(ms)\nhubEnabled(valor)\ncontingenciaEnabled(valor)\nclientId(id)\ntelaAutorizacao(valor)\niniciarServicos(valor)\nemitente(cfg) [obsoleto]\nmotorPort(porta) / hubPort(porta) [não altere]"));

        addTitle("Hub — emissão e operação fiscal");
        addAction("emitir(itens, pagamentos, documento, ref)", this::emitirTipado);
        addAction("emitirJson(json)", this::emitirJson);
        addAction("simular(itens, pagamentos)", () -> {
            ItemVenda item = itemExemplo();
            String parametros = "itens = [" + item + "]"
                    + "\npagamentos = [{forma=credito, valor=12.0}]";
            confirmarEnvio("hub.simular", parametros,
                    () -> run("hub.simular", sdk.hub().simular(Arrays.asList(item), Arrays.asList(new PagamentoVenda("credito", 12.0)))));
        });
        addAction("emitirXml(xml, uuid)", () -> pedir("XML NFC-e", "Cole o XML completo", "", true, xml -> {
            String uuid = "XML-" + UUID.randomUUID();
            confirmarEnvio("hub.emitirXml", "uuid = " + uuid + "\nxml =\n" + xml,
                    () -> run("hub.emitirXml", sdk.hub().emitirXml(xml, uuid)));
        }));
        addAction("cancelar(chave, justificativa)", () -> pedirChaveEJustificativa("Hub cancelar", (chave, justificativa) ->
                confirmarEnvio("hub.cancelar", "chave = " + chave + "\njustificativa = " + justificativa,
                        () -> run("hub.cancelar", sdk.hub().cancelar(chave, justificativa)))));
        addAction("inutilizar(serie, inicial, final, justificativa)", () -> pedir("Justificativa", "Mínimo 15 caracteres", "Teste de inutilizacao", false, justificativa ->
                confirmarEnvio("hub.inutilizar", "serie = 111\ninicial = 920\nfinal = 925\njustificativa = " + justificativa,
                        () -> run("hub.inutilizar", sdk.hub().inutilizar(111, 920, 925, justificativa)))));

        addTitle("Hub — consultas, DANFE e recursos");
        addAction("consultar(chave ou ref)", () -> pedirChaveOuRef(v -> confirmarChamada("hub.consultar", "chaveOuRef = " + v, () -> sdk.hub().consultar(v))));
        addAction("baixarXml(chave)", () -> pedirChave(v -> confirmarChamada("hub.baixarXml", "chave = " + v, () -> sdk.hub().baixarXml(v))));
        addAction("baixarPdf(chave)", () -> pedirChave(v -> confirmarChamada("hub.baixarPdf", "chave = " + v + "\nO PDF será salvo e aberto no visualizador instalado.", () -> sdk.hub().baixarPdf(v))));
        addAction("baixarPdfDetalhado(chave)", () -> pedirChave(v -> confirmarChamada("hub.baixarPdfDetalhado",
                "chave = " + v + "\nO resultado inclui status, bytes e mensagem de erro. Se houver PDF, ele será salvo e aberto.",
                () -> sdk.hub().baixarPdfDetalhado(v))));
        addAction("baixarPdfPara(chave, arquivo)", () -> pedirChave(v -> {
            File destino = new File(getFilesDir(), "danfe-" + v + ".pdf");
            confirmarChamada("hub.baixarPdfPara", "chave = " + v + "\narquivo = " + destino.getAbsolutePath(),
                    () -> sdk.hub().baixarPdfPara(v, destino));
        }));
        addAction("baixarEscpos(chave)", () -> pedirChave(v -> confirmarChamada("hub.baixarEscpos", "chave = " + v, () -> sdk.hub().baixarEscpos(v))));
        addAction("danfePreBaixada(chave) (síncrono)", () -> pedirChave(v -> confirmarEnvio("hub.danfePreBaixada", "chave = " + v,
                () -> mostrar("hub.danfePreBaixada", sdk.hub().danfePreBaixada(v)))));
        addAction("capacidades()", () -> confirmarChamada("hub.capacidades", "parâmetros = nenhum", () -> sdk.hub().capacidades()));
        addAction("eventos(cursor)", () -> pedir("Cursor de eventos", "Cursor (vazio para começar)", "", false, v -> confirmarChamada("hub.eventos", "cursor = " + v, () -> sdk.hub().eventos(v))));
        addAction("health()", () -> confirmarChamada("hub.health", "parâmetros = nenhum", () -> sdk.hub().health()));
        addAction("nativaGet(rota)", () -> pedir("GET nativo", "Rota começando com /", "/api/v1/openapi.json", false, v -> confirmarChamada("hub.nativaGet", "rota = " + v, () -> sdk.hub().nativaGet(v))));
        addAction("nativaPost(rota, json)", () -> pedir("POST nativo — rota", "Rota começando com /", "/api/v1/config/danfe", false, rota ->
                pedir("POST nativo — JSON", "Corpo JSON", "{}", true, json ->
                        confirmarEnvio("hub.nativaPost", "rota = " + rota + "\njson =\n" + json,
                                () -> run("hub.nativaPost", sdk.hub().nativaPost(rota, json))))));

        addTitle("Hub — leitura e gravação de configuração");
        addAction("getConfigHub()", () -> confirmarChamada("hub.getConfigHub", "parâmetros = nenhum", () -> sdk.hub().getConfigHub()));
        addAction("getEmitente()", () -> confirmarChamada("hub.getEmitente", "parâmetros = nenhum", () -> sdk.hub().getEmitente()));
        addAction("getTributacao()", () -> confirmarChamada("hub.getTributacao", "parâmetros = nenhum", () -> sdk.hub().getTributacao()));
        addAction("getConfigMotor()", () -> confirmarChamada("hub.getConfigMotor", "parâmetros = nenhum", () -> sdk.hub().getConfigMotor()));
        addAction("getDanfe()", () -> confirmarChamada("hub.getDanfe", "parâmetros = nenhum", () -> sdk.hub().getDanfe()));
        addAction("getRegras()", () -> confirmarChamada("hub.getRegras", "parâmetros = nenhum", () -> sdk.hub().getRegras()));
        addAction("getWebhook()", () -> confirmarChamada("hub.getWebhook", "parâmetros = nenhum", () -> sdk.hub().getWebhook()));
        addAction("setEmitente(json)", () -> pedir("setEmitente", "JSON do emitente", emitenteExemplo(), true, json ->
                confirmarEnvio("hub.setEmitente", "json =\n" + json, () -> run("hub.setEmitente", sdk.hub().setEmitente(json)))));
        addAction("setTributacao(json)", () -> pedirJsonConfig("setTributacao", sdk.hub()::setTributacao));
        addAction("setConfigMotor(json)", () -> pedirJsonConfig("setConfigMotor", sdk.hub()::setConfigMotor));
        addAction("setRegras(json)", () -> pedirJsonConfig("setRegras", sdk.hub()::setRegras));
        addAction("setDanfe(json)", () -> pedirJsonConfig("setDanfe", sdk.hub()::setDanfe));
        addAction("setWebhook(json)", () -> pedirJsonConfig("setWebhook", sdk.hub()::setWebhook));
        addAction("setClientId(id)", () -> pedir("Client ID", "Mudar o ID pode limpar o provisionamento local", "", false, id ->
                confirmarEnvio("hub.setClientId", "id = " + id + "\n\nSe for diferente do ID gravado, a SDK limpa banco, certificado e autorização.",
                        () -> run("hub.setClientId", sdk.hub().setClientId(id)))));
        addAction("FORMAS_PAGAMENTO", () -> mostrar("SmartDFeHub.FORMAS_PAGAMENTO", SmartDFeHub.FORMAS_PAGAMENTO));

        addTitle("NFC-e — emissão, consulta e DANFE");
        addAction("nfce.emitir(xml, uuid)", () -> pedir("XML NFC-e", "Cole o XML completo", "", true, xml -> {
            String uuid = "NFCe-" + UUID.randomUUID();
            confirmarEnvio("nfce.emitir", "uuid = " + uuid + "\nxml =\n" + xml,
                    () -> run("nfce.emitir", sdk.nfce().emitir(xml, uuid)));
        }));
        addAction("nfce.consultar(chave)", () -> pedirChave(v -> confirmarChamada("nfce.consultar", "chave = " + v, () -> sdk.nfce().consultar(v))));
        addAction("nfce.statusSefaz()", () -> confirmarChamada("nfce.statusSefaz", "parâmetros = nenhum", () -> sdk.nfce().statusSefaz()));
        addAction("nfce.cancelar(chave, justificativa)", () -> pedirChaveEJustificativa("NFC-e cancelar", (chave, justificativa) ->
                confirmarEnvio("nfce.cancelar", "chave = " + chave + "\njustificativa = " + justificativa + "\nnProt = (vazio)",
                        () -> run("nfce.cancelar", sdk.nfce().cancelar(chave, justificativa, "")))));
        addAction("nfce.inutilizar(serie, inicial, final, justificativa)", () -> pedir("Justificativa", "Mínimo 15 caracteres", "Teste de inutilizacao", false, justificativa ->
                confirmarEnvio("nfce.inutilizar", "serie = 111\ninicial = 920\nfinal = 925\njustificativa = " + justificativa,
                        () -> run("nfce.inutilizar", sdk.nfce().inutilizar("111", 920, 925, justificativa)))));
        addAction("nfce.contingencia(acao)", () -> pedir("Contingência", "Ex.: pendentes, enable ou disable", "pendentes", false, v -> {
            if ("pendentes".equalsIgnoreCase(v)) {
                confirmarChamada("nfce.contingencia", "acao = " + v, () -> sdk.nfce().contingencia(v));
            } else {
                confirmarEnvio("nfce.contingencia", "acao = " + v,
                        () -> run("nfce.contingencia", sdk.nfce().contingencia(v)));
            }
        }));
        addAction("nfce.danfePdf(nNF)", () -> pedir("Número da NFC-e", "Número da nota", "1", false, v -> {
            int numero = parseInt(v, 1);
            confirmarChamada("nfce.danfePdf", "nNF = " + numero, () -> sdk.nfce().danfePdf(numero));
        }));
        addAction("nfce.danfeEscpos(nNF, perfil)", () -> pedir("Número da NFC-e", "Número da nota", "1", false, v -> {
            int numero = parseInt(v, 1);
            String perfil = "80mm,qr=raster,corte=total";
            confirmarChamada("nfce.danfeEscpos", "nNF = " + numero + "\nperfil = " + perfil,
                    () -> sdk.nfce().danfeEscpos(numero, perfil));
        }));

        addTitle("NF-e modelo 55");
        addAction("nfe.emitir(xml, uuid)", () -> pedir("XML NF-e modelo 55", "Cole o XML completo", "", true, xml -> {
            String uuid = "NFe-" + UUID.randomUUID();
            confirmarEnvio("nfe.emitir", "uuid = " + uuid + "\nxml =\n" + xml,
                    () -> run("nfe.emitir", sdk.nfe().emitir(xml, uuid)));
        }));
        addAction("nfe.cancelar(chave, justificativa)", () -> pedirChaveEJustificativa("NF-e cancelar", (chave, justificativa) ->
                confirmarEnvio("nfe.cancelar", "chave = " + chave + "\njustificativa = " + justificativa + "\nnProt = (vazio)",
                        () -> run("nfe.cancelar", sdk.nfe().cancelar(chave, justificativa, "")))));
        addAction("nfe.cartaCorrecao(chave, texto)", () -> pedirChave(v -> pedir("Carta de correção", "Texto da correção", "Endereco corrigido", false, texto ->
                confirmarEnvio("nfe.cartaCorrecao", "chave = " + v + "\ntexto = " + texto + "\nsequencia = 1",
                        () -> run("nfe.cartaCorrecao", sdk.nfe().cartaCorrecao(v, texto, 1))))));
        addAction("nfe.manifestar(chave, codigo)", () -> pedirChave(v -> pedir("Manifestação", "210200, 210210, 210220 ou 210240", "210200", false, codigo ->
                {
                    int codigoEvento = parseInt(codigo, 210200);
                    confirmarEnvio("nfe.manifestar", "chave = " + v + "\ncodigo = " + codigoEvento + "\njustificativa = (vazia)",
                            () -> run("nfe.manifestar", sdk.nfe().manifestar(v, codigoEvento, "")));
                })));
        addAction("nfe.statusSefaz()", () -> confirmarChamada("nfe.statusSefaz", "parâmetros = nenhum", () -> sdk.nfe().statusSefaz()));
        addAction("nfe.danfePdf(chave)", () -> pedirChave(v -> confirmarChamada("nfe.danfePdf", "chave = " + v, () -> sdk.nfe().danfePdf(v))));
        addAction("nfe.danfePdfDeXml(xml)", () -> pedir("XML NF-e", "Cole o XML completo", "", true, xml ->
                confirmarChamada("nfe.danfePdfDeXml", "xml =\n" + xml, () -> sdk.nfe().danfePdfDeXml(xml))));

        addTitle("Agente fiscal (FiscalAgentController)");
        addAction("disableFiscalAgent(context, 120, callback)", () -> confirmarEnvio("disableFiscalAgent",
                "context = ApiMethodsActivity.this\ntimeout = 120L\ncallback = atualiza este modal\n\nA SDK tentará drenar as pendências.", () -> {
                    long ticket = abrirModalAguardando("disableFiscalAgent", "Aguardando drenagem de pendências…");
                    fiscalAgent.disableFiscalAgent(this, 120L, result -> {
                        runOnUiThread(() -> concluirModal(ticket, "disableFiscalAgent", formatarResposta(result)));
                        return Unit.INSTANCE;
                    });
                }));
        addAction("enableFiscalAgent(context)", () -> {
            confirmarEnvio("enableFiscalAgent", "context = ApiMethodsActivity.this\n\nVolta a aceitar operações fiscais neste aparelho.", () -> {
                fiscalAgent.enableFiscalAgent(this);
                mostrar("enableFiscalAgent", "chamada concluída");
            });
        });
        addTitle("DFeFuture");
        addNote("thenAccept e exceptionally são usados nas chamadas assíncronas acima. Este botão testa thenApply transformando a configuração em texto.");
        addAction("thenApply(transformação)", () -> confirmarChamada("DFeFuture.thenApply / hub.getConfigHub",
                "getConfigHub()\ntransformação = JSONObject.toString()",
                () -> sdk.hub().getConfigHub().thenApply(config -> config.toString())));
    }

    private void emitirTipado() {
        String ref = "VENDA-" + UUID.randomUUID();
        String parametros = "itens = [" + itemExemplo() + "]"
                + "\npagamentos = [{forma=credito, valor=12.0}]\ndocumentoDestinatario = 12345678909\nref = " + ref
                + "\n\nA emissão usa o ambiente configurado no aparelho.";
        confirmarEnvio("hub.emitir", parametros,
                () -> run("hub.emitir ref=" + ref, sdk.hub().emitir(Arrays.asList(itemExemplo()),
                        Arrays.asList(new PagamentoVenda("credito", 12.0)), "12345678909", ref)));
    }

    private void inicializarSdk() {
        if (status != null) status.setText("Inicializando SmartDFe fora da thread principal…");
        initExecutor.execute(() -> {
            try {
                // telaAutorizacao(TRUE) num aparelho ainda nao provisionado.
                //
                // Com false E sem clientId o SDK nao tem como se provisionar: nao abre
                // tela, ninguem informa o client_id, o motor nunca sobe. A partir da
                // versao de 13/11/2026 o init FALHA NA HORA nesse caso, dizendo isso --
                // antes ele esperava ate o tempo limite e so entao dava erro, que foi o
                // "congelou" observado aqui.
                //
                // Use false apenas quando voce JA tem o client_id em maos:
                //     .clientId("w9Rnu2dlnFYPbRCONYHRp9AF")
                //     .telaAutorizacao(false)
                // Ou desenhe o QR na sua propria tela lendo
                // SmartDFe.estadoProvisionamento(ctx).
                SmartDFeConfig config = new SmartDFeConfig.Builder()
                        .notificacao("SmartDFe SDK Test", "Motor fiscal ativo")
                        .telaAutorizacao(true)
                        .clientId("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
                        .build();
                SmartDFe.init(this, config).thenAccept(inicializado -> {
                    sdk = inicializado;
                    SmartDFe.ativarServico(this).thenAccept(noAr -> {
                        runOnUiThread(() -> reconstruirTela(
                                Boolean.TRUE.equals(noAr)
                                        ? "SmartDFe ativo. Os métodos estão prontos."
                                        : "SDK iniciado, mas o serviço não respondeu. Os métodos estão disponíveis para diagnóstico."));
                        return Unit.INSTANCE;
                    }).exceptionally(erro -> {
                        runOnUiThread(() -> reconstruirTela("Falha ao ativar serviços: " + erro.getMessage()));
                        return null;
                    });
                    return Unit.INSTANCE;
                }).exceptionally(erro -> {
                    runOnUiThread(() -> reconstruirTela("Falha ao inicializar SmartDFe: " + erro.getMessage()));
                    return null;
                });
            } catch (Throwable erro) {
                runOnUiThread(() -> reconstruirTela("Falha ao inicializar SmartDFe: " + erro.getMessage()));
            }
        });
    }

    private void reconstruirTela(String mensagem) {
        content.removeAllViews();
        sectionContent = null;
        actionRow = null;
        actionsInRow = 0;
        criarCabecalho();
        status.setText(mensagem);
        if (sdk != null) {
            montarBotoesApi();
        } else {
            addNote("A inicialização não concluiu. Verifique o Logcat e tente novamente.");
            addAction("Tentar inicializar novamente", this::inicializarSdk);
        }
    }

    private void emitirJson() {
        String ref = "PEDIDO-" + UUID.randomUUID();
        String json = "{\"ref\":\"" + ref + "\",\"ambiente\":\"homologacao\","
                + "\"itens\":[{\"descricao\":\"Arroz Branco\",\"quantidade\":1.0,\"valor_unitario\":12.0,"
                + "\"ncm\":\"10063021\",\"cfop\":\"5102\",\"gtin\":\"SEM GTIN\","
                + "\"tributacao\":{\"origem\":0,\"icms\":{\"csosn\":\"102\",\"modalidade_base\":0},"
                + "\"pis\":{\"cst\":\"49\"},\"cofins\":{\"cst\":\"49\"},"
                + "\"ibs_cbs\":{\"cst\":\"000\",\"cClassTrib\":\"000001\",\"pIBSUF\":0.1,\"pIBSMun\":0.0,\"pCBS\":0.9}}}],"
                + "\"pagamentos\":[{\"forma\":\"credito\",\"valor\":12.0,\"bandeira\":\"01\","
                + "\"cnpj_credenciadora\":\"45984642000100\",\"autorizacao\":\"123456\",\"integrado\":true}]}";
        confirmarEnvio("hub.emitirJson", "json enviado =\n" + json,
                () -> run("hub.emitirJson ref=" + ref, sdk.hub().emitirJson(json)));
    }

    private ItemVenda itemExemplo() {
        return new ItemVenda("Arroz Branco", 1.0, 12.0, "10063021", "5102", "UN", "ARROZ-1", "SEM GTIN", "", 0.0);
    }

    private String emitenteExemplo() {
        return "{\"emitente\":{\"CEP\":\"________\",\"CNPJ\":\"______________\",\"CRT\":\"1\","
                + "\"IE\":\"128237060114\",\"UF\":\"SP\",\"cMun\":\"3550308\",\"cPais\":\"1058\",\"cUF\":\"35\","
                + "\"fone\":\"\",\"nro\":\"871\",\"xBairro\":\"VILA SAO FRANCISCO (ZONA LESTE)\",\"xCpl\":\"\","
                + "\"xFant\":\"_________________________________\",\"xLgr\":\"RUA JOAO JOSE DE QUEIROZ\","
                + "\"xMun\":\"SAO PAULO\",\"xNome\":\"_________________________________\",\"xPais\":\"Brasil\"},\"status\":\"ok\"}";
    }

    private <T> void run(String name, DFeFuture<T> future) {
        long ticket = abrirModalAguardando(name, "Aguardando resposta da SDK…");
        future.thenAccept(value -> {
            boolean chaveSalva = guardarChaveEmitida(name, value);
            runOnUiThread(() -> {
                File pdf = salvarPdfSeAplicavel(name, value);
                concluirModal(ticket, name, formatarResposta(value)
                        + (chaveSalva ? "\n\nÚltima chave de acesso salva: " + ultimaChaveAcesso : "")
                        + (pdf != null ? "\n\nAbrindo PDF: " + pdf.getName() : ""));
                if (pdf != null) abrirPdf(pdf);
            });
            return Unit.INSTANCE;
        }).exceptionally(error -> {
            runOnUiThread(() -> concluirModal(ticket, name, "ERRO: " + error.getMessage()));
            return null;
        });
    }

    private File salvarPdfSeAplicavel(String nome, Object resultado) {
        if (resultado == null || !nome.toLowerCase(java.util.Locale.ROOT).contains("pdf")) return null;
        try {
            File pdf;
            if (resultado instanceof File) {
                pdf = (File) resultado;
            } else {
                byte[] bytes = resultado instanceof byte[] ? (byte[]) resultado : extrairBytesPdfDetalhado(resultado);
                if (!parecePdf(bytes)) return null;
                File pasta = new File(getCacheDir(), "danfe");
                if (!pasta.exists() && !pasta.mkdirs()) throw new IOException("Não foi possível criar a pasta de PDFs.");
                pdf = new File(pasta, "danfe-" + System.currentTimeMillis() + ".pdf");
                try (FileOutputStream saida = new FileOutputStream(pdf)) {
                    saida.write(bytes);
                }
            }
            return pdf.isFile() && parecePdf(pdf) ? pdf : null;
        } catch (Exception erro) {
            android.util.Log.e("SmartDFeApi", "Falha ao preparar PDF para visualização", erro);
            return null;
        }
    }

    private byte[] extrairBytesPdfDetalhado(Object resultado) {
        Object ok = invocarGetter(resultado, "getOk");
        if (ok == null) ok = invocarGetter(resultado, "isOk");
        if (Boolean.FALSE.equals(ok)) return null;
        Object bytes = invocarGetter(resultado, "getBytes");
        if (!(bytes instanceof byte[])) bytes = invocarGetter(resultado, "getPdf");
        return bytes instanceof byte[] ? (byte[]) bytes : null;
    }

    private Object invocarGetter(Object alvo, String nome) {
        try {
            return alvo.getClass().getMethod(nome).invoke(alvo);
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
    }

    private boolean parecePdf(byte[] bytes) {
        return bytes != null && bytes.length >= 5 && bytes[0] == '%'
                && bytes[1] == 'P' && bytes[2] == 'D' && bytes[3] == 'F' && bytes[4] == '-';
    }

    private boolean parecePdf(File arquivo) {
        if (arquivo == null || !arquivo.isFile() || arquivo.length() < 5) return false;
        try (java.io.FileInputStream entrada = new java.io.FileInputStream(arquivo)) {
            byte[] cabecalho = new byte[5];
            return entrada.read(cabecalho) == 5 && parecePdf(cabecalho);
        } catch (IOException ignored) {
            return false;
        }
    }

    private void abrirPdf(File pdf) {
        try {
            Uri uri = androidx.core.content.FileProvider.getUriForFile(this,
                    getPackageName() + ".fileprovider", pdf);
            Intent visualizar = new Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/pdf")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(visualizar, "Abrir DANFE em PDF"));
        } catch (ActivityNotFoundException erro) {
            mostrar("PDF salvo", "Não há visualizador de PDF instalado. Arquivo salvo em: " + pdf.getAbsolutePath());
        } catch (Exception erro) {
            android.util.Log.e("SmartDFeApi", "Não foi possível abrir o PDF", erro);
            mostrar("Falha ao abrir PDF", "O arquivo foi salvo em: " + pdf.getAbsolutePath() + "\n" + erro.getMessage());
        }
    }

    private void aguardarMotorPronto() {
        long ticket = abrirModalAguardando("SmartDFe.isReady", "Verificando o motor…");
        new Thread(() -> {
            long deadline = System.currentTimeMillis() + 10 * 60 * 1000L;
            int tentativa = 0;
            while (System.currentTimeMillis() < deadline && modalAindaAberto(ticket)) {
                tentativa++;
                boolean pronto;
                try {
                    pronto = SmartDFe.isReady();
                } catch (Throwable erro) {
                    pronto = false;
                }
                if (pronto) {
                    runOnUiThread(() -> concluirModal(ticket, "SmartDFe.isReady", "true — motor pronto."));
                    return;
                }
                final int numeroTentativa = tentativa;
                runOnUiThread(() -> atualizarModal(ticket, "SmartDFe.isReady",
                        "Ainda false. Tentativa " + numeroTentativa + "; verificando novamente em 5 segundos…"));
                try { Thread.sleep(5000); } catch (InterruptedException ignored) { return; }
            }
            runOnUiThread(() -> concluirModal(ticket, "SmartDFe.isReady", "Tempo limite atingido; o motor ainda não respondeu true."));
        }, "smartdfe-ready-poll").start();
    }

    private void aguardarAutorizacao() {
        long ticket = abrirModalAguardando("Aguardar autorização", "Consultando estado do provisionamento…");
        new Thread(() -> {
            long deadline = System.currentTimeMillis() + 10 * 60 * 1000L;
            int tentativa = 0;
            while (System.currentTimeMillis() < deadline && modalAindaAberto(ticket)) {
                tentativa++;
                SmartDFe.EstadoProvisionamento estado = SmartDFe.estadoProvisionamento(this);
                if (estado.autorizado) {
                    runOnUiThread(() -> concluirModal(ticket, "Aguardar autorização",
                            "autorizado=true. Feche e reabra o app para o Hub carregar o emitente."));
                    return;
                }
                String codigo = estado.codigoUsuario == null || estado.codigoUsuario.isEmpty()
                        ? "aguardando código de autorização" : "código " + estado.codigoUsuario
                        + " — " + estado.urlVerificacao;
                final int numeroTentativa = tentativa;
                runOnUiThread(() -> atualizarModal(ticket, "Aguardar autorização",
                        codigo + "\nVerificação " + numeroTentativa + "; atualiza em 5 segundos…"));
                try { Thread.sleep(5000); } catch (InterruptedException ignored) { return; }
            }
            runOnUiThread(() -> concluirModal(ticket, "Aguardar autorização", "Tempo limite atingido; o aparelho ainda não foi autorizado."));
        }, "smartdfe-auth-poll").start();
    }

    private void ativarESperar() {
        long ticket = abrirModalAguardando("ativarServico", "Aguardando retorno true/false da SDK…");
        long deadline = System.currentTimeMillis() + 10 * 60 * 1000L;
        tentarAtivar(ticket, deadline, 1);
    }

    private void tentarAtivar(long ticket, long deadline, int tentativa) {
        if (!modalAindaAberto(ticket)) return;
        if (System.currentTimeMillis() >= deadline) {
            concluirModal(ticket, "ativarServico", "Tempo limite atingido; o serviço não retornou true.");
            return;
        }
        atualizarModal(ticket, "ativarServico", "Tentativa " + tentativa + " — aguardando serviço ficar ativo…");
        SmartDFe.ativarServico(this).thenAccept(noAr -> {
            if (Boolean.TRUE.equals(noAr)) {
                runOnUiThread(() -> concluirModal(ticket, "ativarServico", "true — serviço ativo."));
            } else {
                runOnUiThread(() -> atualizarModal(ticket, "ativarServico",
                        "Retornou false. Nova tentativa em 5 segundos…"));
                mainHandler.postDelayed(() -> tentarAtivar(ticket, deadline, tentativa + 1), 5000);
            }
            return Unit.INSTANCE;
        }).exceptionally(error -> {
            runOnUiThread(() -> atualizarModal(ticket, "ativarServico",
                    "Erro: " + error.getMessage() + "\nNova tentativa em 5 segundos…"));
            mainHandler.postDelayed(() -> tentarAtivar(ticket, deadline, tentativa + 1), 5000);
            return null;
        });
    }

    private long abrirModalAguardando(String titulo, String mensagem) {
        if (activeResponseDialog != null && activeResponseDialog.isShowing()) {
            activeResponseDialog.setOnDismissListener(null);
            activeResponseDialog.dismiss();
        }
        long ticket = ++dialogSequence;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(titulo)
                .setMessage(mensagem)
                .setPositiveButton("Fechar", null)
                .create();
        activeResponseDialog = dialog;
        dialog.setOnDismissListener(ignored -> {
            if (activeResponseDialog == dialog) {
                activeResponseDialog = null;
                dialogSequence++;
            }
        });
        dialog.show();
        aplicarEstiloMensagem(dialog, mensagem);
        return ticket;
    }

    private boolean modalAindaAberto(long ticket) {
        return ticket == dialogSequence;
    }

    private void atualizarModal(long ticket, String titulo, String mensagem) {
        if (!modalAindaAberto(ticket) || activeResponseDialog == null || !activeResponseDialog.isShowing()) return;
        activeResponseDialog.setTitle(titulo);
        activeResponseDialog.setMessage(mensagem);
        aplicarEstiloMensagem(activeResponseDialog, mensagem);
    }

    private void concluirModal(long ticket, String titulo, String mensagem) {
        if (!modalAindaAberto(ticket) || activeResponseDialog == null || !activeResponseDialog.isShowing()) return;
        activeResponseDialog.setTitle(titulo);
        activeResponseDialog.setMessage(mensagem);
        aplicarEstiloMensagem(activeResponseDialog, mensagem);
    }

    private void mostrarProvisionamento() {
        SmartDFe.EstadoProvisionamento e = SmartDFe.estadoProvisionamento(this);
        mostrar("estadoProvisionamento", "clientId=" + e.clientId + "\nautorizado=" + e.autorizado
                + "\ncodigoUsuario=" + e.codigoUsuario + "\nurlVerificacao=" + e.urlVerificacao
                + "\nurlComCodigo=" + e.urlComCodigo);
    }

    private void pedirChave(ValorCallback callback) {
        pedir("Chave da nota", "44 dígitos; vazio usa a última chave", "", false, digitada -> {
            String chave = digitada.trim().isEmpty() ? ultimaChaveAcesso : digitada.trim();
            if (chave.isEmpty()) {
                mostrar("Chave da nota", "Nenhuma chave foi informada e ainda não há uma última chave de acesso salva. Emita uma nota ou digite a chave.");
                return;
            }
            callback.accept(chave);
        });
    }

    private void pedirChaveOuRef(ValorCallback callback) {
        pedir("Consulta", "Chave, ref; vazio usa a última chave", "", false, digitada -> {
            String valor = digitada.trim().isEmpty() ? ultimaChaveAcesso : digitada.trim();
            if (valor.isEmpty()) {
                mostrar("Consulta", "Nenhuma chave foi informada e ainda não há uma última chave de acesso salva.");
                return;
            }
            callback.accept(valor);
        });
    }

    private boolean guardarChaveEmitida(String nome, Object resultado) {
        if (resultado == null || !(nome.startsWith("hub.emitir")
                || nome.startsWith("nfce.emitir") || nome.startsWith("nfe.emitir"))) return false;
        try {
            Object emitida = resultado.getClass().getMethod("getEmitida").invoke(resultado);
            Object chave = resultado.getClass().getMethod("getChave").invoke(resultado);
            if (Boolean.TRUE.equals(emitida) && chave != null && chave.toString().matches("\\d{44}")) {
                ultimaChaveAcesso = chave.toString();
                getSharedPreferences(PREFS_NOTAS, MODE_PRIVATE).edit()
                        .putString(PREF_ULTIMA_CHAVE, ultimaChaveAcesso).apply();
                android.util.Log.i("SmartDFeApi", "Última chave de acesso salva: " + ultimaChaveAcesso);
                return true;
            }
        } catch (ReflectiveOperationException ignored) {
            android.util.Log.w("SmartDFeApi", "Não foi possível ler a chave do resultado de " + nome);
        }
        return false;
    }

    private void pedirChaveEJustificativa(String titulo, DuploCallback callback) {
        pedirChave(chave -> pedir(titulo, "Justificativa (mínimo 15 caracteres)", "Cancelamento solicitado pelo cliente", false,
                justificativa -> callback.accept(chave, justificativa)));
    }

    private void pedirJsonConfig(String titulo, JsonSetter setter) {
        pedir(titulo, "JSON completo da configuração", "{}", true, json ->
                confirmarEnvio(titulo, "json enviado =\n" + json,
                        () -> run(titulo, setter.set(json))));
    }

    private <T> void confirmarChamada(String nome, String parametros, Supplier<DFeFuture<T>> chamada) {
        confirmarEnvio(nome, parametros, () -> run(nome, chamada.get()));
    }

    private void pedir(String title, String hint, String initial, boolean multiline, ValorCallback callback) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setText(initial);
        if (multiline) {
            input.setSingleLine(false);
            input.setMinLines(3);
            input.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        } else {
            input.setSingleLine(true);
        }
        int pad = dp(20);
        input.setPadding(pad, dp(8), pad, 0);
        new AlertDialog.Builder(this).setTitle(title).setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Continuar", (dialog, which) -> callback.accept(input.getText().toString().trim()))
                .show();
    }

    private void confirmarEnvio(String title, String parametros, Runnable action) {
        TextView preview = new TextView(this);
        preview.setText(parametros);
        preview.setTextSize(14);
        preview.setTypeface(android.graphics.Typeface.MONOSPACE);
        preview.setTextIsSelectable(true);
        preview.setPadding(dp(16), dp(12), dp(16), dp(12));

        ScrollView previewScroll = new ScrollView(this);
        previewScroll.setFillViewport(true);
        previewScroll.addView(preview, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        previewScroll.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(360)));

        new AlertDialog.Builder(this).setTitle("Revisar: " + title).setView(previewScroll)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("OK, enviar", (dialog, which) -> action.run())
                .show();
    }

    private void addTitle(String text) {
        fecharLinhaAcoes();
        if (content.getChildCount() > 0) {
            View divider = new View(this);
            divider.setBackgroundColor(getColor(R.color.line_soft));
            LinearLayout.LayoutParams dividerParams = fullWidth();
            dividerParams.height = dp(1);
            dividerParams.setMargins(0, dp(30), 0, dp(18));
            content.addView(divider, dividerParams);
        }
        sectionContent = content;

        LinearLayout cabecalho = new LinearLayout(this);
        cabecalho.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView icone = new TextView(this);
        icone.setText(iconeSecao(text));
        icone.setTextColor(getColor(R.color.ink_navy));
        icone.setTextSize(26);
        cabecalho.addView(icone, new LinearLayout.LayoutParams(dp(46), dp(38)));
        TextView view = new TextView(this);
        view.setText(tituloSecao(text));
        view.setTextSize(25);
        view.setTextColor(getColor(R.color.ink_navy));
        view.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        cabecalho.addView(view, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        cabecalho.setTag(tituloSecao(text));
        content.addView(cabecalho, fullWidth());
    }

    private void addNote(String text) {
        fecharLinhaAcoes();
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(14);
        view.setTextColor(getColor(R.color.ink_muted));
        view.setPadding(0, 0, 0, dp(12));
        (sectionContent == null ? content : sectionContent).addView(view, fullWidth());
    }

    private void addAction(String title, Runnable action) {
        if (actionRow == null || (!twoColumns && actionsInRow == 1) || (twoColumns && actionsInRow == 2)) {
            actionRow = new LinearLayout(this);
            actionRow.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams rowParams = fullWidth();
            rowParams.setMargins(0, dp(10), 0, 0);
            content.addView(actionRow, rowParams);
            actionsInRow = 0;
        }
        View card = criarCartaoAcao(title, action);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(twoColumns ? 0 : ViewGroup.LayoutParams.MATCH_PARENT,
                dp(86), twoColumns ? 1f : 0f);
        if (twoColumns && actionsInRow == 0) params.setMargins(0, 0, dp(12), 0);
        actionRow.addView(card, params);
        actionsInRow++;
    }

    private View criarCartaoAcao(String titulo, Runnable action) {
        boolean perigosa = titulo.startsWith("zerar") || titulo.contains("force") || titulo.contains("desativar");
        LinearLayout card = new LinearLayout(this);
        card.setGravity(android.view.Gravity.CENTER_VERTICAL);
        card.setPadding(dp(18), dp(10), dp(14), dp(10));
        GradientDrawable fundo = new GradientDrawable();
        fundo.setColor(getColor(perigosa ? R.color.surface_danger : R.color.white));
        fundo.setCornerRadius(dp(16));
        fundo.setStroke(dp(1), getColor(perigosa ? R.color.line_danger : R.color.line_soft));
        card.setBackground(fundo);
        card.setClickable(true);
        card.setFocusable(true);
        card.setOnClickListener(v -> action.run());

        TextView icon = new TextView(this);
        icon.setText(iconeAcao(titulo));
        icon.setTextSize(27);
        icon.setGravity(android.view.Gravity.CENTER);
        icon.setTextColor(getColor(perigosa ? R.color.action_danger : R.color.action_blue));
        card.addView(icon, new LinearLayout.LayoutParams(dp(54), ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout texto = new LinearLayout(this);
        texto.setOrientation(LinearLayout.VERTICAL);
        texto.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView nome = new TextView(this);
        nome.setText(titulo);
        nome.setTextColor(getColor(R.color.ink_navy));
        nome.setTextSize(16);
        nome.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        nome.setMaxLines(1);
        texto.addView(nome, fullWidth());
        TextView descricao = new TextView(this);
        descricao.setText(descricaoAcao(titulo));
        descricao.setTextColor(getColor(R.color.ink_body));
        descricao.setTextSize(13);
        descricao.setMaxLines(1);
        texto.addView(descricao, fullWidth());
        card.addView(texto, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));

        MaterialButton executar = new MaterialButton(this);
        executar.setText("▶");
        executar.setTextSize(18);
        executar.setTextColor(getColor(perigosa ? R.color.action_danger : R.color.action_blue));
        executar.setPadding(0, 0, 0, 0);
        executar.setInsetTop(0);
        executar.setInsetBottom(0);
        executar.setCornerRadius(dp(12));
        executar.setBackgroundTintList(ColorStateList.valueOf(getColor(perigosa ? R.color.action_danger_soft : R.color.action_blue_soft)));
        executar.setOnClickListener(v -> action.run());
        card.addView(executar, new LinearLayout.LayoutParams(dp(52), dp(48)));
        return card;
    }

    private void fecharLinhaAcoes() {
        if (actionRow != null && twoColumns && actionsInRow == 1) {
            View espaco = new View(this);
            actionRow.addView(espaco, new LinearLayout.LayoutParams(0, dp(86), 1f));
        }
        actionRow = null;
        actionsInRow = 0;
    }

    private String tituloSecao(String texto) {
        if (texto.toLowerCase(java.util.Locale.ROOT).contains("provisionamento")) return "Provisionamento";
        if (texto.contains("Hub")) return "Hub";
        if (texto.contains("NFC")) return "NFC-e";
        if (texto.contains("NF-e")) return "NF-e";
        if (texto.contains("Serviço")) return "Serviço";
        if (texto.contains("Limpeza")) return "Limpeza";
        if (texto.contains("Configuração")) return "Configuração";
        if (texto.contains("Agente fiscal")) return "Agente fiscal";
        if (texto.contains("DFeFuture")) return "DFeFuture";
        return texto;
    }

    private String iconeSecao(String texto) {
        if (texto.contains("provisionamento")) return "▱";
        if (texto.contains("Config")) return "☷";
        if (texto.contains("NFC") || texto.contains("NF-e")) return "◫";
        return "⌁";
    }

    private String iconeAcao(String titulo) {
        if (titulo.startsWith("zerar")) return "♲";
        if (titulo.contains("cancelar")) return "⊘";
        if (titulo.contains("baixar") || titulo.contains("danfe")) return "⇩";
        if (titulo.contains("emitir")) return "▣";
        if (titulo.contains("status") || titulo.contains("isReady")) return "⌁";
        return "◇";
    }

    private String descricaoAcao(String titulo) {
        if (titulo.contains("estadoProvisionamento")) return "Consulta o estado do provisionamento.";
        if (titulo.contains("Aguardar autorização")) return "Aguarda a autorização do ambiente.";
        if (titulo.contains("isReady")) return "Verifica se o serviço está pronto.";
        if (titulo.startsWith("ativar")) return "Ativa o serviço fiscal.";
        if (titulo.startsWith("desativar")) return "Desativa o serviço fiscal.";
        if (titulo.startsWith("zerar")) return "Remove o provisionamento local.";
        if (titulo.contains("emitir")) return "Envia uma emissão para o ambiente.";
        if (titulo.contains("baixar") || titulo.contains("danfe")) return "Obtém o documento da nota.";
        if (titulo.contains("consultar")) return "Consulta uma nota fiscal.";
        return "Executa este método da API.";
    }

    private void mostrar(String name, Object value) {
        abrirModalAguardando(name, formatarResposta(value));
    }

    private String formatarResposta(Object value) {
        String text;
        if (value instanceof byte[]) {
            text = "ByteArray: " + ((byte[]) value).length + " bytes";
        } else if (value instanceof File) {
            text = ((File) value).getAbsolutePath();
        } else if (value instanceof org.json.JSONObject) {
            try { text = ((org.json.JSONObject) value).toString(2); }
            catch (org.json.JSONException erro) { text = value.toString(); }
        } else if (value instanceof org.json.JSONArray) {
            try { text = ((org.json.JSONArray) value).toString(2); }
            catch (org.json.JSONException erro) { text = value.toString(); }
        } else {
            text = formatarJsonSePossivel(String.valueOf(value));
            if (value != null) {
                String diagnostico = diagnosticoEmissao(value);
                if (!diagnostico.isEmpty()) text += "\n\nDiagnóstico da rejeição:\n" + diagnostico;
            }
        }
        android.util.Log.i("SmartDFeApi", text);
        return text;
    }

    private String formatarJsonSePossivel(String text) {
        if (text == null) return "null";
        String limpo = text.trim();
        if (limpo.startsWith("{")) {
            try { return new org.json.JSONObject(limpo).toString(2); }
            catch (org.json.JSONException ignored) { return text; }
        }
        if (limpo.startsWith("[")) {
            try { return new org.json.JSONArray(limpo).toString(2); }
            catch (org.json.JSONException ignored) { return text; }
        }
        return text;
    }

    private void aplicarEstiloMensagem(AlertDialog dialog, String mensagem) {
        TextView corpo = dialog.findViewById(android.R.id.message);
        if (corpo == null) return;
        String texto = mensagem == null ? "" : mensagem.trim();
        if (texto.startsWith("{") || texto.startsWith("[")) {
            corpo.setTypeface(android.graphics.Typeface.MONOSPACE);
            corpo.setTextSize(13);
            corpo.setTextIsSelectable(true);
            corpo.setLineSpacing(dp(2), 1.0f);
        }
    }

    private String diagnosticoEmissao(Object value) {
        StringBuilder resultado = new StringBuilder();
        String[] getters = {"getCampo", "getProblema", "getAcao"};
        String[] labels = {"campo", "problema", "ação"};
        for (int i = 0; i < getters.length; i++) {
            try {
                Object campo = value.getClass().getMethod(getters[i]).invoke(value);
                if (campo != null && !campo.toString().trim().isEmpty()) {
                    if (resultado.length() > 0) resultado.append('\n');
                    resultado.append(labels[i]).append(" = ").append(campo);
                }
            } catch (ReflectiveOperationException ignored) {
                return "";
            }
        }
        return resultado.toString();
    }

    private int parseInt(String value, int fallback) {
        try { return Integer.parseInt(value); } catch (NumberFormatException ignored) { return fallback; }
    }

    private LinearLayout.LayoutParams fullWidth() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        initExecutor.shutdown();
        super.onDestroy();
    }

    private interface ValorCallback { void accept(String value); }
    private interface DuploCallback { void accept(String first, String second); }
    private interface JsonSetter { DFeFuture<?> set(String json); }
}
