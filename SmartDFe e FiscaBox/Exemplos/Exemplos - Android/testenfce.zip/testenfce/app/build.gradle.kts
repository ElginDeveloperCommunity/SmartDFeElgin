plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.testenfce"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "com.example.testenfce"
        minSdk = 24
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = true
                packageScope = setOf("androidx.**", "kotlin.**", "kotlinx.**")
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation(libs.activity.ktx)
    implementation(libs.appcompat)
    implementation(libs.constraintlayout)
    implementation(libs.material)
    testImplementation(libs.junit)
    androidTestImplementation(libs.espresso.core)
    androidTestImplementation(libs.ext.junit)

    implementation(files("libs/sdk-release.aar"))

    // NAO declare o QtAndroid.jar aqui. Consumindo o AAR por arquivo, as classes do
    // Qt ja vem dentro dele, e declarar o jar outra vez derruba o build com ~120
    // linhas de "Duplicate class org.qtproject.qt5.android.*". O jar acompanha o
    // pacote em libs/ apenas para quem consome o SDK como MODULO do mesmo build.

    // O SDK e escrito em Kotlin, e num app Java puro o stdlib nao chega sozinho:
    // sem ele a lambda do callback (Function1/Unit) nem compila.
    implementation("org.jetbrains.kotlin:kotlin-stdlib:1.9.24")

    // appcompat e declarado como implementation dentro do AAR, entao nao e transitivo.
    implementation("androidx.appcompat:appcompat:1.7.0")

    // ZXing: NECESSARIO para ler o QR do client_id pela CAMERA na tela de
    // provisionamento do SDK. Mesmo motivo do appcompat acima -- um .aar consumido
    // como ARQUIVO nao traz dependencia transitiva, porque arquivo nao carrega
    // metadado.
    //
    // Sem estas duas a tela AINDA ABRE e a entrada manual funciona (o SDK passou a
    // degradar em 13/11/2026, antes disso crashava com NoClassDefFoundError), mas o
    // botao da camera nao aparece e o log SmartDFe-prov avisa.
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
    implementation("com.google.zxing:core:3.5.3")

    // OBRIGATORIA, mesmo que este app nao use ConstraintLayout em tela nenhuma: os
    // layouts das telas de provisionamento que vem DENTRO do AAR usam atributos de
    // ConstraintLayout, e o resource linking do AAPT resolve os atributos de TODOS os
    // layouts empacotados — inclusive os que o seu fluxo nunca abre.
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
}